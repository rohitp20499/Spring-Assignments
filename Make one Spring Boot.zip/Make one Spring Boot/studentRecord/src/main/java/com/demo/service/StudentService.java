package com.demo.service;

import java.util.List;

import com.demo.model.StudentRecord;

public interface StudentService {

	StudentRecord getStudentById(int id);

	StudentRecord addStudent(StudentRecord student);

	String updateStudent(StudentRecord student, int id);

	String deleteStudent(int id);

	List<StudentRecord> getAll();

}
