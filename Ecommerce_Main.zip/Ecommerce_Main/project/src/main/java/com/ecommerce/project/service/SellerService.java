package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.model.Seller;

public interface SellerService {

	Seller addProduct(Seller seller);

	List<Seller> findAllSellers();

	List<Seller> searchSellerByName(String name);

	String updateSeller(Seller seller, int id);

	String deleteSeller(int id);

	

}
