package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.model.Seller;
import com.ecommerce.project.service.SellerService;

@CrossOrigin("*")
@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private SellerService sService;

	@PostMapping("/create")
	public ResponseEntity<Seller> addSeller(@RequestBody Seller seller){
		 return new ResponseEntity<Seller>(sService.addProduct(seller),HttpStatus.CREATED);
	}
	
	@GetMapping("/getall")
	public ResponseEntity<List<Seller>> findAllSellers(){
		return new ResponseEntity<List<Seller>>(sService.findAllSellers(),HttpStatus.OK);
	}
	
	@GetMapping("/search/{name}")
	public ResponseEntity<List<Seller>> searchSellerByName(@PathVariable String name){
		 return new ResponseEntity<List<Seller>>(sService.searchSellerByName(name),HttpStatus.OK);
	}
	
	@PutMapping("/updateDetails")
	public String updateSeller(@RequestBody Seller seller,@PathVariable int id){
		return sService.updateSeller(seller,id);
	}
	
	@DeleteMapping("/delete")
	public String deleteSeller(@PathVariable int id) {
		return sService.deleteSeller(id);
	}
}
