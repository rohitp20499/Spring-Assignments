package com.ecommerce.project.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "pur_generator")
	@SequenceGenerator(name = "pur_generator",initialValue = 1000,allocationSize = 1,sequenceName = "pur_seq")
	private int id;
	private int productId;
	private int purchaseQuantity;
	private int buyerId;
	private Date purchaseDate;
}
