package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.PurchaseHistory;

public interface BuyerService {

	List<Product> searchProductByName(String name);

	List<Product> searchProductByMake(String make);

	List<Product> searchProductByModel(String model);

	List<Product> searchProductByPrice(float lowPrice, float highPrice);

	String purchaseProduct(int id, int quantity);

	List<PurchaseHistory> purchaseHistory();

	
}
