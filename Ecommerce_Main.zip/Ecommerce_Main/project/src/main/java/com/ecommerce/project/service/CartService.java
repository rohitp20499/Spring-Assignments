package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.model.Product;

public interface CartService {

	String addToShoppingCart(int id, int quantity);

	List<Product> getMyCart();

	String remove(int id);

}
