package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.PurchaseHistory;
import com.ecommerce.project.service.BuyerService;

@CrossOrigin("*")
@RestController
@RequestMapping("/buyer")
public class BuyerController {

	@Autowired
	private BuyerService bService;
	
	@GetMapping("/searchName")
	public ResponseEntity<List<Product>> searchProductByName(@RequestParam String name){
		return new ResponseEntity<List<Product>>(bService.searchProductByName(name),HttpStatus.OK);
	}
	
//	@GetMapping("/search")
//	public Product searchProductByName(@RequestParam String name){
//		return pService.searchProductByName(name);
//	}
	
	@GetMapping("/searchMake/{make}")
	public ResponseEntity<List<Product>> searchProductByMake(@PathVariable String make){
		return new ResponseEntity<List<Product>>(bService.searchProductByMake(make),HttpStatus.OK);
	}
	
	@GetMapping("/searchModel/{model}")
	public ResponseEntity<List<Product>> searchProductByModel(@PathVariable String model){
		return new ResponseEntity<List<Product>>(bService.searchProductByModel(model),HttpStatus.OK);
	}
	
	@GetMapping("/search/{lowPrice}/{highPrice}")
	public ResponseEntity<List<Product>> searchProductByPrice(@PathVariable float lowPrice,@PathVariable float highPrice){
		return new ResponseEntity<List<Product>>(bService.searchProductByPrice(lowPrice,highPrice),HttpStatus.OK);
	}
	
	@GetMapping("purchase/{id}/{quantity}")
	public ResponseEntity<String> purchaseProduct(@PathVariable int id,@PathVariable int quantity){
		return new ResponseEntity<String>(bService.purchaseProduct(id,quantity),HttpStatus.OK);
	}
	
	@GetMapping("/gethistory")
	public ResponseEntity<List<PurchaseHistory>> getPurchaseHistory() {
		return new ResponseEntity<List<PurchaseHistory>>(bService.purchaseHistory(),HttpStatus.OK);
		
	}
}
