package com.ecommerce.project.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.exception.RecordNotFoundException;
import com.ecommerce.project.model.Buyer;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.ShoppingCart;
import com.ecommerce.project.repository.ProductRepository;
import com.ecommerce.project.repository.ShoppingCartRepo;
import com.ecommerce.project.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private ShoppingCartRepo scRepo;
	
	@Autowired
	private ProductRepository pRepo;
	
//	@Autowired
//	Buyer buyer;
	
	@Override
	public String addToShoppingCart(int id, int quantity) {
		Optional<Product> prod = pRepo.findById(id);
		Buyer buyer = new Buyer();
		if(prod.isPresent()) {
			Product product = prod.get();
			if(quantity>product.getQuantity()) {
				throw new RecordNotFoundException("Out of Stock !!");
			}
			product.setQuantity(product.getQuantity()-quantity);
			pRepo.save(product);
			ShoppingCart cart = new ShoppingCart();
			cart.setProductId(product.getId());
			cart.setPurchaseQuantity(quantity);
			cart.setBuyerId(buyer.getId());
			scRepo.save(cart);
		} else {
			throw new RecordNotFoundException("There is no existing Product with the Id : "+id);
		}
		return "Product Added to cart !";
	}

	@Override
	public List<Product> getMyCart() {
		List<ShoppingCart> sc = scRepo.findAll();
		if(sc.isEmpty()) {
			throw new RecordNotFoundException("There is no product in the Cart!!");
		} 
		List<Product> plist = new ArrayList<Product>();
		for(ShoppingCart s : sc) {
			Optional<Product> p = pRepo.findById(s.getId());
			plist.add(p.get());
		}
		return plist;
	}

	@Override
	public String remove(int id) {
		scRepo.deleteById(id);
		return "Item Removed  !!";
	}

}
