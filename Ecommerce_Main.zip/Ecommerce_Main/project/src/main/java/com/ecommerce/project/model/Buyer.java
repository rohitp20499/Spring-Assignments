package com.ecommerce.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Buyer {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "buyer_generator")
	@SequenceGenerator(name = "buyer_generator",initialValue = 100,allocationSize = 1,sequenceName = "buy_seq")
	private int id;
	private String userName;
	private String password;
	private String emailId;
}
