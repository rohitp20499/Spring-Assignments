package com.ecommerce.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Seller {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seller_generator")
	@SequenceGenerator(name = "seller_generator",initialValue = 10,allocationSize = 1,sequenceName = "sel_seq")
	private int id;
	
	private String userName;
	private String password;
	private String emailId;
	private String companyName;
	private String companyDescription;
	private String role;
}
