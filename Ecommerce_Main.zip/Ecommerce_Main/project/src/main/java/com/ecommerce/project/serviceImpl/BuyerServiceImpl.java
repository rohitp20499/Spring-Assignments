package com.ecommerce.project.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.exception.RecordNotFoundException;
import com.ecommerce.project.model.Buyer;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.PurchaseHistory;
import com.ecommerce.project.repository.ProductRepository;
import com.ecommerce.project.repository.PurchaseHistoryRepo;
import com.ecommerce.project.repository.ShoppingCartRepo;
import com.ecommerce.project.service.BuyerService;

@Service
public class BuyerServiceImpl implements BuyerService {

	@Autowired
	private ProductRepository pRepo;
	
	@Autowired
	private ShoppingCartRepo scRepo;
	
	
	@Autowired
	private PurchaseHistoryRepo phRepo;
	
	
//	Buyer buyer;
	
	

	Date date;
	
	@Override
	public List<Product> searchProductByName(String name) {
		return pRepo.findByName(name);
	}

	@Override
	public List<Product> searchProductByMake(String make) {
		return pRepo.findByMake(make);
	}

	@Override
	public List<Product> searchProductByModel(String model) {
		return pRepo.findByModel(model);
	}

	@Override
	public List<Product> searchProductByPrice(float lowPrice, float highPrice) {
		return pRepo.findByPriceBetween(lowPrice, highPrice);
	}

	@Override
	public String purchaseProduct(int id, int quantity) {
		Optional<Product> prod = pRepo.findById(id);
		Buyer buyer = new Buyer();
		if(prod.isPresent()) {
			Product product = prod.get();
			if(quantity>product.getQuantity()) {
				throw new RecordNotFoundException("Out of Stock !!");
			}
			if(!scRepo.findById(id).isPresent()) {
				product.setQuantity(product.getQuantity()-quantity);
			}
			pRepo.save(product);
			PurchaseHistory cart = new PurchaseHistory();
			cart.setProductId(product.getId());
			cart.setPurchaseQuantity(quantity);
			cart.setBuyerId(buyer.getId());
			cart.setPurchaseDate(date=java.util.Calendar.getInstance().getTime());
			phRepo.save(cart);
		} else {
			throw new RecordNotFoundException("There is no existing Product with the Id : "+id);
		}
		return "Product Purchased successfully";
	}

	@Override
	public List<PurchaseHistory> purchaseHistory() {
		return phRepo.findAll();
	}
	
	

}
