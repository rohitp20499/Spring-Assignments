package com.ecommerce.project.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "prod_generator")
	@SequenceGenerator(name = "prod_generator", initialValue = 1, allocationSize = 1, sequenceName = "pr_seq")
	private int id;

	@Column(name = "name")
	@NotNull(message = "Name may not be null")
	private String name;

	@Column(name = "model")
	private String model;

	@Column(name = "make")
	private String make;

	@Column(name = "categoryId")
	private int categoryId;

	@Column(name = "sub_categoryId")
	private int sub_categoryId;

	@Column(name = "price")
	private float price;

	@Column(name = "quantity")
	private int quantity;

	@Column(name = "image")
	private String image;

	@Column(name = "specifications")
	private String specifications;

	@Column(name = "status")
	private String status;

	@Column(name = "sellerId")
	private int sellerId;

}
