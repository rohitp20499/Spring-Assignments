package com.ecommerce.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.project.model.PurchaseHistory;

public interface PurchaseHistoryRepo extends JpaRepository<PurchaseHistory, Integer> {

}
