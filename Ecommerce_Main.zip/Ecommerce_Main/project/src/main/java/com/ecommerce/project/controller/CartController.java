package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.model.Product;
import com.ecommerce.project.service.CartService;

@CrossOrigin("*")
@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cService;
	
	@GetMapping("/addToCart/{id}/{quantity}")
	public ResponseEntity<String> addToShoppingCart(@PathVariable int id, @PathVariable int quantity){
		return new ResponseEntity<String>(cService.addToShoppingCart(id,quantity),HttpStatus.OK);
	}
	
	@GetMapping("/shoppingCart")
	public ResponseEntity<List<Product>> getShoppingCart(){
		return new ResponseEntity<List<Product>>(cService.getMyCart(),HttpStatus.OK);
	}
	
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeProductFromCart(@PathVariable int id){
		return new ResponseEntity<String>(cService.remove(id),HttpStatus.OK);
	}
}
