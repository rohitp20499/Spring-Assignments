package com.ecommerce.project.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.exception.RecordNotFoundException;
import com.ecommerce.project.model.Seller;
import com.ecommerce.project.repository.SellerRepository;
import com.ecommerce.project.service.SellerService;

@Service
public class SellerServiceImpl implements SellerService {

	@Autowired
	private SellerRepository sRepo;
	
	@Override
	public Seller addProduct(Seller seller) {
		return sRepo.save(seller);
	}

	@Override
	public List<Seller> findAllSellers() {
		return sRepo.findAll();
	}

	@Override
	public List<Seller> searchSellerByName(String name) {
		return sRepo.findByUserName(name);
	}

	@Override
	public String updateSeller(Seller seller, int id) {
		Optional<Seller> s = sRepo.findById(id);
		if(s.isPresent()) {
			Seller s1 = s.get();
			s1.setUserName(seller.getUserName());
			s1.setPassword(seller.getPassword());
			s1.setEmailId(seller.getEmailId());
			s1.setCompanyName(seller.getCompanyName());
			s1.setCompanyDescription(seller.getCompanyDescription());
			s1.setRole(seller.getRole());
			sRepo.save(s1);
		} else {
			throw new RecordNotFoundException("There is no record with id "+id);
		}
		return  "Record Updated successfully";
	}

	@Override
	public String deleteSeller(int id) {
		sRepo.deleteById(id);
		return "Record Deleted successfully!!";
	}
	
	

}
