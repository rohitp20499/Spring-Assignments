package com.ecommerce.project.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.exception.RecordNotFoundException;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.repository.ProductRepository;
import com.ecommerce.project.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository pRepo;

	@Override
	public Product addProduct(Product product) {
		return pRepo.save(product);
	}

	@Override
	public List<Product> searchProductByName(String name) {
		return pRepo.findByName(name);
	}

	@Override
	public List<Product> findAllProducts() {
		return pRepo.findAll();
	}
	
	@Override
	public Product searchProductById(int id) {
		Optional<Product> p = pRepo.findById(id);
		if(!p.isPresent()) 
			throw new RecordNotFoundException("Product with Id "+id+" doesn't exist");
		return p.get();
	}

	@Override
	public String deleteById(int id) {
		pRepo.deleteById(id);
		return "Product deleted successfully.";
	}

	@Override
	public String updateProduct(int id, Product product) {
		Optional<Product> p = pRepo.findById(id);
		if(p.isPresent()) {
			Product prod = p.get();
			prod.setName(product.getName());
			prod.setMake(product.getMake());
			prod.setModel(product.getModel());
			prod.setCategoryId(product.getCategoryId());
			prod.setSub_categoryId(product.getSub_categoryId());
			prod.setPrice(product.getPrice());
			prod.setQuantity(product.getQuantity());
			prod.setSpecifications(product.getSpecifications());
			prod.setSellerId(product.getSellerId());
			prod.setStatus(product.getStatus());
			prod.setImage(product.getImage());
			pRepo.save(prod);			
		} else {
			throw new RecordNotFoundException("There is no record with id "+id);
		}
		return "Product Updated Successfully.";
	}

}
