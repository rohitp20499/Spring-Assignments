package com.ecommerce.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.project.model.Seller;

public interface SellerRepository extends JpaRepository<Seller, Integer> {

	List<Seller> findByUserName(String userName);

}
