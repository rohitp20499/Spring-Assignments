package com.ecommerce.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.project.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	List<Product> findByName(String name);
	
	List<Product> findByMake(String make);
	
	List<Product> findByModel(String model);
	
	List<Product> findByPriceBetween(float lowPrice,float highPrice);

}
