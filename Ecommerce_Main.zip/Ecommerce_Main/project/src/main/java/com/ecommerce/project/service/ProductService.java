package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.model.Product;

public interface ProductService {

	public Product addProduct(Product product);

	public List<Product> searchProductByName(String name);

	public List<Product> findAllProducts();

	public Product searchProductById(int id);

	public String deleteById(int id);

	public String updateProduct(int id, Product product);
}
