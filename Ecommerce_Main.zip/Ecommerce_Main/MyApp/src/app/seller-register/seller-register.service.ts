import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Seller } from './seller';

@Injectable({
  providedIn: 'root'
})
export class SellerRegisterService {

  private apiServerurl=environment.apiBaseurl;
  
  constructor(private http: HttpClient) { }

   public getSeller() : Observable<any> {
      return this.http.get<any>(`${this.apiServerurl}/seller/getall`);
    }

    public addSeller(seller : Seller) : Observable<Seller> {
      return this.http.post<Seller>(`${this.apiServerurl}/seller/create`, seller);
    }
    // public updateSeller(sellerId:number, seller:Seller): Observable<Seller> {
    //   return this.http.put<Seller>(`${this.apiServerurl}/seller/update/${sellerId}`, seller);
    // }
  
    // public deleteSeller(sellerId: number): Observable<void> {
    //   return this.http.delete<void>(`${this.apiServerurl}/seller/delete/${sellerId},{responseType:'text'}`);
    // }
}
