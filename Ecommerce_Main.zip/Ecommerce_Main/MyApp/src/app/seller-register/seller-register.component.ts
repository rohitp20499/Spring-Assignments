import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, NgForm, Validators } from '@angular/forms';
import { Seller } from './seller';
import { SellerRegisterService } from './seller-register.service';

@Component({
  selector: 'app-seller-register',
  templateUrl: './seller-register.component.html',
  styleUrls: ['./seller-register.component.css']
})
export class SellerRegisterComponent implements OnInit {
  public seller: Seller[] = [];
  public seller1!:Seller;
  
  emailFormControl= new FormControl('',[
    Validators.required,
    Validators.email
  ]);

  constructor(private sellerRegisterService:SellerRegisterService) { }

  ngOnInit(): void {
  }

   
  public getProduct(): void {
    this.sellerRegisterService.getSeller().subscribe({
      next: (result:Seller[]) => { 
       this.seller = result;
        console.log(this.seller);
      },
      error: (err: HttpErrorResponse) => {
        alert(err.message);
      }
     } );
  }

  public onAddProduct(addForm: NgForm): void {
   // document.getElementById('add-product-form')!.click();
    this.sellerRegisterService.addSeller(addForm.value).subscribe(
      (response: Seller) => {
        console.log(response);
        alert("Registration Successful! Proceed to login.")
        this.getProduct();
        addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
        addForm.reset();
      }
    );
  }
  }

     
   