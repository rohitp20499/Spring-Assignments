export interface Seller{
    id:number;
    userName:string;
    password:string;
    emailId:string;
    companyName:string;
    companyDescription:string;
    role:string;
    

}