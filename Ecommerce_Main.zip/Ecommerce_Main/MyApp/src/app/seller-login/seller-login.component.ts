import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl,  Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    selector: 'app-seller-login',
    templateUrl: './seller-login.component.html',
    styleUrls: ['./seller-login.component.css'],
})
export class SellerLoginComponent implements OnInit {
  credentials={
    username:'',
    password:''
  } 
  constructor(private router: Router){
    }
      
    emailFormControl= new FormControl('',[
      Validators.required,
      Validators.email
    ]);
  
    ngOnInit() {
    }

    onSubmit(){
      console.log("form is submitted");
         if((this.credentials.username=='ADMIN@gmail.com' && this.credentials.password=='ADMIN') && (this.credentials.username!=null && this.credentials.password!=null))
      {
        this.router.navigate(['']);   
        }
       else{
        alert("Enter valid Email Id and password");
       }
    }
}
