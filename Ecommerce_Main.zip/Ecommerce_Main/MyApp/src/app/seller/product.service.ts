import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private apiServerurl=environment.apiBaseurl;
  
  constructor(private http: HttpClient) { }

  public getProduct() : Observable<any> {
    console.log("Im in get")
    return this.http.get<any>(`${this.apiServerurl}/product/getall`);
  }

  public addProduct(product : Product) : Observable<Product> {
    return this.http.post<Product>(`${this.apiServerurl}/product/create`, product);
  }
  public updateProduct(productId:number, product:Product): Observable<Product> {
    return this.http.put<Product>(`${this.apiServerurl}/product/update/${productId}`, product);
  }

  public deleteProduct(productId:number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerurl}/product/delete/${productId}`);
  }
}
