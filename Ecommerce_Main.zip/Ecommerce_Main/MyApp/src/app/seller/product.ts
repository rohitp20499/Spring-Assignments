export interface Product{
    id:number;
    name:string;
    make:string;
    model:string;
    categoryId:string;
    sub_categoryId:string;
    price:number;
    quantity:number;
    image:string;
    specifications:string;
    status:string;
    sellerId:number;


}