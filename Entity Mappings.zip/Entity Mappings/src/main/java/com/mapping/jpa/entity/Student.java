package com.mapping.jpa.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "stu_generator")
	@SequenceGenerator(name = "stu_generator",initialValue = 10,allocationSize = 1,sequenceName = "stu_sequence")
	private int id;
	private String name;
	private String college;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "fk_cls")
	private ClassRoom classRoom;

	
	
}
