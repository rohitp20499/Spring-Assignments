package com.mapping.jpa.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.jpa.entity.ClassRoom;

public interface ClasssRepo extends JpaRepository<ClassRoom, Integer> {

}
