package com.mapping.jpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClassRoom {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "cls_generator")
	@SequenceGenerator(name = "cls_generator",initialValue = 1,allocationSize = 1,sequenceName = "cls_sequence")
	private int id;
	private String roomName;
	

}
