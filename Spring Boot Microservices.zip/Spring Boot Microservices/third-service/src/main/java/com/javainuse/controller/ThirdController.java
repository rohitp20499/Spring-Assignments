package com.javainuse.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/retailer")
public class ThirdController {

	@GetMapping("/get")
	public String test() {
		return "Hello JavaInUse Called in Third Service";
	}
}
