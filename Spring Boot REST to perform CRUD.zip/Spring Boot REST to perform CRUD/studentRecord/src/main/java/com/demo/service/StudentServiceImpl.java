package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.StudentRecord;
import com.demo.repository.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepo sRepo;

	@Override
	public StudentRecord getStudentById(int id) {

		Optional<StudentRecord> s = sRepo.findById(id);
		if(!s.isPresent())
			System.out.println("Student with id "+id+" is not present.");
		return s.get();
	}

	@Override
	public StudentRecord addStudent(StudentRecord student) {
		return sRepo.save(student);
	}

	@Override
	public String updateStudent(StudentRecord student, int id) {
		 Optional<StudentRecord> s = sRepo.findById(id);
		 if(s.isPresent()) {
			 student.setId(id);
			 sRepo.save(student);
		 } else {
			 System.out.println("Student with id "+id+" is not present.");			 
		 }
		return "Record updated Successfully!";
	}

	@Override
	public String deleteStudent(int id) {
		sRepo.deleteById(id);;
		return "Record deleted successfully!!";
	}

	@Override
	public List<StudentRecord> getAll() {
		return sRepo.findAll();
	}

}
