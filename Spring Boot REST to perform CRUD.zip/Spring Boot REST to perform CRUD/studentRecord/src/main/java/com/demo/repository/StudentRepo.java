package com.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.model.StudentRecord;

public interface StudentRepo extends JpaRepository<StudentRecord, Integer> {

}
