package com.restOne.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/first")
public class DemoController {

	@GetMapping("/get")
	public String getResult() {
		return "Result From Student Report";
	}
}
