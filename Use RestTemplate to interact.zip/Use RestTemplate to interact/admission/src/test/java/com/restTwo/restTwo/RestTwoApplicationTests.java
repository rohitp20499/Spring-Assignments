package com.restTwo.restTwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
