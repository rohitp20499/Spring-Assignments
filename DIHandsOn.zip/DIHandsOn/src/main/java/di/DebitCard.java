package di;

public class DebitCard implements Card{
	
	public void details() {
		System.out.println("This is Debit Card");
	}

}
