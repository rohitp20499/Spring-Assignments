package di;

public class CreditCard implements Card{

	public void details() {
		System.out.println("This is Credit Card");
	}
}
