package com.eg1;

public interface IArithService {
    int iadd(int x, int y);
    int isub(int x, int y);
    int imul(int x, int y);
    float iavg(int x, int y);
}
