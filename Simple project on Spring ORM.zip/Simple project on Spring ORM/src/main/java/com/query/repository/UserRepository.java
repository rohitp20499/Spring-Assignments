package com.query.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.query.bean.User;

public interface UserRepository extends JpaRepository<User, Long>
{
	List<User> findByNameAndCountry(String name, String country);
	
	@Query(value="select new com.query.repository.UserCountryName(U.country, U.name) from User U")
	List<UserCountryName> findAbc();
	
	@Query(value="select new com.query.repository.UserCountryName(U.country, U.name) from User U where U.name=?1")
	List<UserCountryName> findAbc1(String str);
	
	@Query(value="select U.country, U.name from user_info U", nativeQuery=true)
	List<Object[]> findXyz();
	
	@Query("SELECT u FROM User u WHERE u.country = :country") //Named parameter
	List<User> findUserByCountry(@Param("country") String country);
	 
	
	@Query("SELECT u FROM User u WHERE u.name = :name")
	User findUserByName(@Param("name") String name);
}
