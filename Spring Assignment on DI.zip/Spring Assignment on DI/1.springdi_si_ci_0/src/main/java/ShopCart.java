
public class ShopCart {

	public ShopCart() {
		System.out.println("ShopCart().....");
	}
	public void cart() {
		System.out.println("Item Added to cart...");
	}
	public void payment() {
		System.out.println("Payment Done...");
	}
}
