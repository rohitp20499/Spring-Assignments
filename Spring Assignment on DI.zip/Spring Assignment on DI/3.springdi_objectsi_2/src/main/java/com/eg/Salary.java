package com.eg;

public class Salary {
	private int id;	
	private float amount;
	public Salary() {
		System.out.println("salary() called");
	}
	public Salary(int id, float amount) {
		this.id = id;
		this.amount = amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Salary [id=" + id + ", amount=" + amount + "]";
	}
}
