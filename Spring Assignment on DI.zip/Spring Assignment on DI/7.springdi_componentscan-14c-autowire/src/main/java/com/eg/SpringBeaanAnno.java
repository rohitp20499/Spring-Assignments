package com.eg;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.eg1.ShoppingCart;
import com.eg2.Product;

@Configuration
@ComponentScan(basePackages = {"com.eg2"})
class subClass{
	
}

@Configuration
@ComponentScan(basePackages = { "com.eg", "com.eg1"})
public class SpringBeaanAnno {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(SpringBeaanAnno.class);

		 ctx.register(subClass.class);
		// ctx.refresh();

		A oa = ctx.getBean(A.class);
		System.out.println(oa);

		Employee emp = (Employee) ctx.getBean("emp", oa);
		emp.setName("name1");

		System.out.println(emp.getName());

		A oa1 = ctx.getBean(A.class);
		ShoppingCart scart = ctx.getBean(com.eg1.ShoppingCart.class);
		System.out.println(scart.addItem(12,"Washing Machine",21230));
		
		List<Product> products = scart.getProductLists();
		for(Product p : products) {
			System.out.println(p);
		}
	}
}
