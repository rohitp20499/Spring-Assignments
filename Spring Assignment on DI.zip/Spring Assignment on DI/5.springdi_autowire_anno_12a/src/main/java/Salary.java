public class Salary {
   public Salary(){
       
      System.out.println("Inside Salary constructor." );
   }

   public void checkSalary() {
      System.out.println("Inside checkSalary..." );
   }
   
}
