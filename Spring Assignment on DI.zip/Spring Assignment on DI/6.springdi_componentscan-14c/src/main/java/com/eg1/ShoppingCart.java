package com.eg1;

import org.springframework.stereotype.Component;

@Component
public class ShoppingCart {

	public String addItem(String item_name) {
		return item_name+" is added";
	}
}
