package com.eg2;

import org.springframework.stereotype.Component;

@Component
public class Product {

	private String pname;
	private String desc;
	private int quantity;
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Product(String pname, String desc, int quantity) {
		this.pname = pname;
		this.desc = desc;
		this.quantity = quantity;
	}
	public Product() {
		System.out.println("In Product Class...");
	}
	
	public void productDetails() {
		System.out.println(pname+" : "+desc+" : "+quantity);
	}
}
