import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.eg.Employee;
import com.eg.XyzEMail;  
  
public class MainApp2 {  
    public static void main(String[] args) {  
          
        Resource r=new ClassPathResource("applicationContext1.xml");  
        BeanFactory factory=new XmlBeanFactory(r);  
        
        XyzEMail obj1=(XyzEMail)factory.getBean("mail"); 
        obj1.sendMail();
        obj1.recvMail();

        Employee s=(Employee)factory.getBean("e"); 
        System.out.println(s);
        
        Employee s1=(Employee)factory.getBean("e1","name1", 25.55, "xyzzzzz"); 
        s1.show();   

    }  
}
