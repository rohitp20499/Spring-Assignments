package com.admission.demo;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/second")
public class RestTwoController {

	@GetMapping("/getall")
	public String met1() {
		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8089/first/get";
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);

		// Verify request succeed
		System.out.println("Status code: " + result.getStatusCodeValue());
		System.out.println("result: " + result.getBody());

		return "Status code: " + result.getStatusCodeValue() + "<br>result: " + result.getBody();
	}
}
