package com.admission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestTwoApplication.class, args);
	}

}
